#ifndef alloca_h
#define alloca_h

#include "../NativePath.h"

#endif