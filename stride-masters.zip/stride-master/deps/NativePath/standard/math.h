#ifndef math_h
#define math_h

#include "../NativePath.h"

#endif