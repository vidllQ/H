#ifndef malloc_h
#define malloc_h

#include "../NativeMemory.h"

#endif