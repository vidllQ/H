## Sources

Compiled from [custom repository](https://github.com/stride3d/gettextnet)
Original fork from [Gettext.NET](https://sourceforge.net/projects/gettextnet/) (LGPL 2.1)