Forks:
WIN8.1/UWP: https://github.com/sinkingsugar/openal-soft-winphone
iOS: Due to LGPL limitations on openal-soft, we are using Apple OpenAL implementation
Other platforms: https://github.com/sinkingsugar/openal-soft