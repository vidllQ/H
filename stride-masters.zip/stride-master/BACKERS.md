Sponsors & Backers
==================

Stride is a MIT-licensed opensource project, supported by generous [sponsors and backers](https://github.com/stride3d/stride/blob/master/BACKERS.md).

[Become a sponsor or backer for the project](https://opencollective.com/stride3d).

Thank you everybody for your generous contributions!

## Diamond Strider

* David Jeske
* [Marshmallow Laser Feast](http://www.marshmallowlaserfeast.com/)
* [vvvv.org](https://vvvv.org/)

## Platinum Strider

## Gold Strider
* Vaclac Elias

## Silver Strider
* Mitchel Albertz

## Bronze Strider
* Marian Dziubiak
* Youness KAFIA
* Jorn Aggror


## Backers

* Amin Delavar
* [Nicolas Musset](https://github.com/Kryptos-FR)
* Ravn Ivarson
* Guy Godin
* Princess Peach
* Adisibio
* Philippe Monteil
* Cobalt
* Matthias Hölzl
* Marko Viitanen
* [Natan Sinigaglia](https://github.com/vvvv-dottore)
* [Jarmo](https://github.com/devjarmo)
* [Eideren](https://github.com/Eideren)
* [profan](https://github.com/profan)
* [Faerdan](https://github.com/Faerdan)
* [sebllll](https://github.com/sebllll)
* [SoulRider](https://github.com/SoulRider)
* [tebjan](https://github.com/tebjan)
* [ideonella](https://github.com/ideonella)
* [Marian Dziubiak](https://github.com/manio143)
* [TheKeyblader](https://github.com/TheKeyblader)
* Boris Callens
* Daniel Keenan
* Jeff Kesselman
* Sean Connor
* Regan Laitila
* Albeoris
* Артем Куприянов
* Miles Johnson
* Ancient Phoenix

