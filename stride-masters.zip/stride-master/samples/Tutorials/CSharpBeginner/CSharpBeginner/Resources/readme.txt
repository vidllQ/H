# Help
There are videos and a manual that go with this tutorial:
 - https://www.youtube.com/watch?v=Z2kUQhSmdr0&list=PLRZx2y7uC8mNySUMfOQf-TLNVnnHkLfPi
 - https://doc.stride3d.net/latest/en/tutorials/csharpbeginner/index.html
 - Feel free to ask any questions in the Discord or use the GitHub issues board to notify of bugs
 
# Use
When launching the project you will be provided with 2 menus.

1. On the left there will be examples you can implement your self.
2. On the right there are working examples for you to use.
