using VRSandbox;

using var game = new VRGame();
game.Run();

