using Stride.Engine;

using var game = new Game();
game.Run();

