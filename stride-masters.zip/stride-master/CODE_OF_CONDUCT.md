As a [.NET Foundation](https://www.dotnetfoundation.org/) project, Stride has adopted the code of conduct defined by the [Contributor Covenant](https://www.contributor-covenant.org/) to clarify the expected behavior within our community. 

For more information, please see the [.NET Foundation Code of Conduct](https://dotnetfoundation.org/code-of-conduct).
